exports.handler = async (event) =>  {
    return 'lambda function working';
}
